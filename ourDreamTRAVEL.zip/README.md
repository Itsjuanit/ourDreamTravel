# Proyecto Our Dream Travel

## Table of Contents

- [Contenido](#about)
- [¿Comó comenzar?](#getting_started)
- [Uso](#usage)
- [Autor](../CONTRIBUTING.md)

## Sobre Our Dream Travel <a name = "about"></a>

El proyecto consta de una pagina web simple, con algunas pantallas, toda la pagina es responsive. Our Dream Travel es una empresa que se dedica a vender 
viajes a medida o en paquetes, brindando la mejor atención posible.

## ¿Comó comenzar? <a name = "getting_started"></a>

Es un proyecto donde se intenta mantener a los clientes y que estos realicen un contacto o compra. lo que llamaos un call to action.
Para comenzar, usar git clone o descargar el archivo zip.

### Pre requisitios

Instalar SASS, yo personalmente, uso un pluggin de VSC llamado Sass compiller, con Live Server

```
Give examples
```

### Instalando

1-Descargar el zip del proyecto o realizar git clone.
2-Instalar Sass
3-Descargar glide.js o usar el cdn, en el proyecto ya viene con cdn.


## Uso <a name = "usage"></a>
Hay un live <a href="http://ourdreamtravel.tur.ar/">demo</a>.

### PORTFOLIO
<a href="https://portfolio-itsjuanit.now.sh/">Itsjuanit</a>